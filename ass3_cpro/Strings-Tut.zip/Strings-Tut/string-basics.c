#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Strings Tutorial

// Q-sort -> Average Case NlogN
// Note its worst case is still N^2
// Included in stdlib.h

int main(){
    char s_to_int[5] = "104";

    printf("Converted to string: %d\n",atoi(s_to_int));

    // I would recommend this declaration when string is known.
    
    // You cannot work with this when you want to take input from user.

    char s_dec1[] = "String_Declaration_1";

    /* 
       The size of the character array is just present to show the maximum buffer size which
       the string can store.
    */

    // Declare maximum buffer size of the string.
    char s_dec2[50] = "String_Declaration_2";
    
    printf("%s\n",s_dec1);

    printf("%s\n",s_dec2);

    printf("Length Of String-1 is : %d\n", strlen(s_dec1));

    // '\0'
    
    printf("Sizeof string: %d\n",sizeof(s_dec1));

    char s_1[15] = "UG-";
    char s_2[15] = "2K23";

    // O(N)
    strcat(s_1,s_2);

    // strcat of a,b => It will append string b to the end of string a
    
    // String Concatenation runs in Linear Time -> O(N)
    printf("Concactenated String: %s\n",s_1);

    // String Copy
    char copied_string[50];

    strcpy(copied_string,s_1);

    printf("Copied String: %s\n",copied_string);

    // There is also something known as strncpy
    // It is used for copying only the first n characters of one string to the other
    // I will give resources for this after the session

    // String Comparision
    
    printf("Strcmp Result: %d\n", strcmp(s_dec1,s_dec2));

    // Similar to strncpy, we also have strncmp which compares first n characters of 2 strings
    return 0;
}