#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// O(N^2)
void bubble_sort(int nonames, char **names)
{
    if (nonames == 0)
    {
        return;
    }
    for (int i = 1; i < nonames; i++)
        if (strcmp(names[i], names[i - 1]) < 0)
        {
            char tempname[100];
            strcpy(tempname, names[i]);
            strcpy(names[i], names[i - 1]);
            strcpy(names[i - 1], tempname);
        }
    bubble_sort(nonames - 1, names);
    return;
}

int main()
{
    char **names;
    int count = 10;
    
    names = (char **)malloc(count * sizeof(char *));
    for(int i=0;i<count;i++){
        names[i]=(char*)malloc(100 * sizeof(char));
    }

    for(int i=0;i<count;i++){
        scanf("%s",names[i]);
    }
    
    bubble_sort(count, names);

    int temp = 10;

    printf("After Sorting: \n");
    
    for (int i = 0; i < count; i++)
    {   
        printf("String %d : %s\n", i+1, names[i]);
    }

}
